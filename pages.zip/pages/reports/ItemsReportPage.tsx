
import React from 'react';
import ReportPlaceholderPage from './ReportPlaceholderPage';

const ItemsReportPage: React.FC = () => {
    return <ReportPlaceholderPage title="Items Report" />;
};

export default ItemsReportPage;
