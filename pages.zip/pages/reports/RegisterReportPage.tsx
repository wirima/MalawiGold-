
import React from 'react';
import ReportPlaceholderPage from './ReportPlaceholderPage';

const RegisterReportPage: React.FC = () => {
    return <ReportPlaceholderPage title="Register Report" />;
};

export default RegisterReportPage;
