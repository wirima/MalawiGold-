
import React from 'react';
import ReportPlaceholderPage from './ReportPlaceholderPage';

const SalesRepReportPage: React.FC = () => {
    return <ReportPlaceholderPage title="Sales Representative Report" />;
};

export default SalesRepReportPage;
