
import React from 'react';
import ReportPlaceholderPage from './ReportPlaceholderPage';

const ActivityLogPage: React.FC = () => {
    return <ReportPlaceholderPage title="Activity Log" />;
};

export default ActivityLogPage;
